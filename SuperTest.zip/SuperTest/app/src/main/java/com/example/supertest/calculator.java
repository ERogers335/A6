package com.example.supertest;

import android.view.View;
import android.widget.*;
import android.widget.Toast;

public class calculator  {

    private int total;
    private int surface;
    private int surfaceCharge;
    private int numOfDrawers;
    private int drawerCharge;
    private int woodCharge;
    final int MIN_CHARGE;
    private MainActivity mActivity;

    public calculator (MainActivity activity){
        mActivity = activity;
        MIN_CHARGE = 200;
        total = MIN_CHARGE;
    }

    /**
     * This is the main method for the application. It calculates/displays the total from the information entered
     * by the user.
     *
     * @param v
     */
    public void calculateTotal(View v) {

        v.setEnabled(false);

        EditText num = mActivity.findViewById(R.id.editTextNumber2);
        numOfDrawers = 0;
        try {
            numOfDrawers = Integer.parseInt(num.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(mActivity, "Please enter something for # of drawers", Toast.LENGTH_LONG).show();
            return;
        }
        drawerCharge = getDrawerCharge(numOfDrawers);


        EditText num2 =  mActivity.findViewById(R.id.editTextNumber);
        surface = 0;
        try {
            surface = Integer.parseInt(num2.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(mActivity, "Please enter something for surface area", Toast.LENGTH_LONG).show();
            return;
        }
        surfaceCharge = getSurfaceCharge(surface);
        woodCharge = getWoodCharge();

        total += drawerCharge + woodCharge + surfaceCharge;
        TextView myTextView = mActivity.findViewById(R.id.priceBox);


        EditText name = mActivity.findViewById(R.id.editTextTextPersonName);
        String custName = name.getText().toString();

        EditText numb = mActivity.findViewById(R.id.editTextNumber3);
        String orderNum = numb.getText().toString();

        myTextView.setText("Order Details - Name: "+ custName +", Order #: "+ orderNum +", Total Price: "+total+"$");
    }


    /**
     * This method resets the variables, textview text, and button so that a user could change detals
     * or price another desk.
     *
     * @param v
     */
    public void resetApp(View v) {
        String defText = "Order Details: ";
        final Button calcTotalButton = mActivity.findViewById(R.id.button);
        calcTotalButton.setEnabled(true);

        TextView myTextView = mActivity.findViewById(R.id.priceBox);
        myTextView.setText(defText);

        drawerCharge = 0;
        surfaceCharge = 0;
        surface = 0;
        numOfDrawers = 0;
        woodCharge = 0;
        total = MIN_CHARGE;

    }

    /**
     * Calculate the charge for the number of drawers in the desk
     *
     * @param numOfDrawers
     */
    protected int getDrawerCharge(int numOfDrawers) {
        int flatDrawerCharge = 30;
        drawerCharge = (numOfDrawers * flatDrawerCharge);

        return drawerCharge;
    }

    /**
     * Calculate the charge, if any, for the larger surface area of the desk.
     *
     * @param surface
     * @return surfaceCharge
     */
    protected int getSurfaceCharge(int surface) {
        int big_desk = 750;
        if (surface > big_desk) {
            surfaceCharge = 50;
        }
        return surfaceCharge;
    }

    /**
     * Calculate the charge, if any, for the type of wood selected for the desk.
     *
     * @return woodCharge
     */
    protected int getWoodCharge() {
        int mahoganyCharge = 150;
        int oakCharge = 125;
        int pineCharge = 0;

        RadioGroup radioGroup = mActivity.findViewById(R.id.radioGroup);
        int selectedId = radioGroup.getCheckedRadioButtonId();

        if (selectedId == -1) {
            Toast.makeText(mActivity, "Please select a wood type!", Toast.LENGTH_LONG).show();
        } else {
            RadioButton radioButton = mActivity.findViewById(selectedId);
            String selectedText = radioButton.getText().toString();

            if (selectedText.equals("Oak")) {
                woodCharge = oakCharge;
            } else if (selectedText.equals("Pine")) {
                woodCharge = pineCharge;
            } else {
                woodCharge = mahoganyCharge;
            }
        }
        return woodCharge;
    }
}

